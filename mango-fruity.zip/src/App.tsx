import { useState, useEffect, useRef } from 'react';
import { AnimatePresence } from 'motion/react';
import Lenis from 'lenis';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useGSAP } from '@gsap/react';
import { LoadingScreen } from './components/LoadingScreen';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { Features } from './components/Features';
import { Products } from './components/Products';
import { Visuals } from './components/Visuals';
import { Footer } from './components/Footer';

gsap.registerPlugin(ScrollTrigger);

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Lenis smooth scrolling
    const lenis = new Lenis({
      duration: 1.2,
      easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
      orientation: 'vertical',
      gestureOrientation: 'vertical',
      smoothWheel: true,
      touchMultiplier: 2,
    });

    lenis.on('scroll', ScrollTrigger.update);

    gsap.ticker.add((time) => {
      lenis.raf(time * 1000);
    });
    gsap.ticker.lagSmoothing(0);

    return () => {
      lenis.destroy();
      gsap.ticker.remove(lenis.raf);
    };
  }, []);

  useGSAP(() => {
    if (isLoading) return;

    // Scroll Progress Bar
    gsap.to('#progress-bar', {
      scaleX: 1,
      ease: 'none',
      scrollTrigger: {
        trigger: document.body,
        start: 'top top',
        end: 'bottom bottom',
        scrub: 0.1,
      },
    });

    // Cinematic Global Can Journey (Futuristic 3D spins and scales)
    const bottleTl = gsap.timeline({
      scrollTrigger: {
        trigger: containerRef.current,
        start: 'top top',
        end: 'bottom bottom',
        scrub: 1.5,
      },
    });

    bottleTl
      .to('#global-bottle', {
        y: '40vh',
        x: '-5vw',
        rotationZ: -10,
        rotationY: 180,
        scale: 0.8,
        ease: 'power2.inOut',
        filter: 'drop-shadow(0 0 30px rgba(255,193,7,0.8))',
      }, 0.1) // Left side at Features
      .to('#global-bottle', {
        y: '100vh',
        x: '20vw',
        rotationZ: 15,
        rotationY: 360,
        scale: 1.3,
        ease: 'power2.inOut',
        filter: 'drop-shadow(0 0 50px rgba(255,193,7,1))',
      }, 0.3) // Right side near Products entry
      .to('#global-bottle', {
        y: '220vh',
        x: '0vw',
        rotationZ: -5,
        rotationY: 720,
        scale: 0.5,
        ease: 'power3.inOut',
        opacity: 0,
        filter: 'drop-shadow(0 0 20px rgba(255,193,7,0))',
      }, 0.6); // Fades into Visuals

  }, { dependencies: [isLoading], scope: containerRef });

  return (
    <div className="min-h-screen bg-cream font-sans text-body selection:bg-mango selection:text-dark-brown relative" ref={containerRef}>
      {/* Background that ties it all together seamlessly */}
      <div className="fixed inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-light via-cream to-mango/10 pointer-events-none z-0"></div>

      {/* Scroll Progress Bar */}
      <div 
        id="progress-bar" 
        className="fixed top-0 left-0 right-0 h-1.5 bg-gradient-to-r from-mango via-golden to-deep origin-left scale-x-0 z-[100] shadow-[0_0_10px_rgba(255,193,7,0.8)]"
      />

      {/* Futuristic Global Can (Amrut Fresh Style) */}
      {!isLoading && (
        <div 
          id="global-bottle" 
          className="fixed top-[15%] left-1/2 -translate-x-1/2 w-[70px] h-[220px] md:w-[120px] md:h-[380px] z-30 pointer-events-none drop-shadow-[0_20px_40px_rgba(0,0,0,0.5)] opacity-0 sm:opacity-100 flex flex-col items-center bg-gradient-to-b from-white via-white to-mango rounded-[2rem] border-x-2 border-white/80 overflow-hidden transform-style-3d border-t-4 border-b-4 border-t-gray-300 border-b-gray-400"
        >
          {/* Top Silver Lip */}
          <div className="w-full h-1.5 md:h-3 bg-gradient-to-r from-gray-400 via-gray-100 to-gray-500 flex-shrink-0 relative overflow-hidden">
             <div className="absolute inset-0 bg-white/50 -skew-x-12 animate-[shimmer_2s_infinite]"></div>
          </div>

          <div className="w-full flex-1 flex flex-col items-center pt-4 md:pt-8 px-2 md:px-4 relative overflow-hidden bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] bg-blend-overlay">
            {/* Red Logo Box */}
            <div className="bg-gradient-to-b from-[#E31837] to-[#B71C1C] text-white w-12 h-12 md:w-24 md:h-24 rounded flex flex-col justify-center items-center font-display font-bold leading-none mb-2 md:mb-6 shadow-[0_4px_10px_rgba(227,24,55,0.4)] z-10 border border-white/20">
              <span className="text-[10px] md:text-xl tracking-wider">AMRUT</span>
              <span className="text-[10px] md:text-xl tracking-wider">FRESH</span>
            </div>

            {/* Subtext */}
            <div className="text-center z-10 mb-4 md:mb-8">
              <div className="font-sans font-black text-dark-brown text-[8px] md:text-sm tracking-[0.2em] md:tracking-[0.3em] leading-tight">SPARKLING</div>
              <div className="font-sans font-medium text-dark-brown text-[5px] md:text-[8px] tracking-widest opacity-80">FLAVOURED DRINK</div>
            </div>

            {/* Futuristic Mango Graphic Area */}
            <div className="relative w-full flex-1 flex flex-col items-center z-10">
              {/* Glowing Aura */}
              <div className="absolute top-0 w-16 h-16 md:w-28 md:h-28 bg-mango/50 blur-xl rounded-full"></div>
              {/* Mango Shape */}
              <div className="absolute top-0 w-12 h-12 md:w-24 md:h-24 bg-gradient-to-br from-[#FF5252] via-[#FF9800] to-mango rounded-full opacity-95 shadow-[inset_-5px_-5px_15px_rgba(0,0,0,0.2)] md:translate-x-[-15px] translate-x-[-8px]"></div>
              {/* Leaf */}
              <div className="absolute top-1 md:top-2 w-6 h-3 md:w-10 md:h-5 bg-gradient-to-r from-green-400 to-green-600 rounded-full -rotate-12 translate-x-[-15px] md:translate-x-[-30px] origin-right shadow-sm border border-green-300/30"></div>
              {/* Cubes */}
              <div className="absolute top-6 md:top-10 w-4 h-4 md:w-8 md:h-8 bg-gradient-to-br from-golden to-mango rounded-sm translate-x-[10px] md:translate-x-[20px] rotate-12 shadow-md border border-white/30 backdrop-blur-sm"></div>
              <div className="absolute top-8 md:top-14 w-3 h-3 md:w-6 md:h-6 bg-gradient-to-br from-mango to-deep rounded-sm translate-x-[2px] md:translate-x-[5px] -rotate-12 shadow-md border border-white/30"></div>

              {/* Text */}
              <div className="absolute bottom-2 md:bottom-6 font-display font-black text-white text-lg md:text-[2.5rem] tracking-wide drop-shadow-[0_2px_8px_rgba(0,0,0,0.5)]">
                Mango
              </div>
            </div>

            {/* Fizz / Bubbles in the liquid part */}
            <div className="absolute bottom-0 left-0 w-full h-[55%] bg-gradient-to-t from-golden via-mango/80 to-transparent z-0 opacity-90 mix-blend-overlay border-t border-white/10"></div>
            
            {/* Dynamic Bubbles */}
            {[...Array(8)].map((_, i) => (
              <div 
                key={i} 
                className="absolute border border-white/60 bg-white/10 rounded-full"
                style={{
                  width: Math.random() * 8 + 2 + 'px',
                  height: Math.random() * 8 + 2 + 'px',
                  bottom: Math.random() * 40 + 10 + '%',
                  left: Math.random() * 80 + 10 + '%',
                  opacity: Math.random() * 0.5 + 0.3
                }}
              ></div>
            ))}
          </div>

          {/* Glossy Specular Highlight to make it look like a 3D cylinder */}
          <div className="absolute inset-0 bg-gradient-to-r from-black/20 via-transparent to-black/20 pointer-events-none rounded-[2rem]"></div>
          <div className="absolute inset-0 w-[40%] bg-gradient-to-r from-transparent via-white/70 to-transparent pointer-events-none translate-x-[25%] skew-x-12 mix-blend-overlay"></div>
          
          {/* Bottom Silver Lip */}
          <div className="w-full h-1.5 md:h-3 bg-gradient-to-r from-gray-500 via-gray-200 to-gray-400 flex-shrink-0 relative overflow-hidden">
             <div className="absolute inset-0 bg-white/50 -skew-x-12 animate-[shimmer_2s_infinite]"></div>
          </div>
        </div>
      )}

      <AnimatePresence mode="wait">
        {isLoading && <LoadingScreen onLoaded={() => setIsLoading(false)} />}
      </AnimatePresence>

      {!isLoading && (
        <div className="relative z-10 w-full overflow-hidden">
          <Navbar />
          <Hero />
          <Features />
          <Products />
          <Visuals />
          <Footer />
        </div>
      )}
    </div>
  );
}
