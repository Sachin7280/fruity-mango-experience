import { motion } from 'motion/react';
import { useEffect, useState } from 'react';

export function LoadingScreen({ onLoaded }: { onLoaded: () => void }) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(onLoaded, 500); // Wait a bit before transitioning
          return 100;
        }
        return prev + Math.floor(Math.random() * 15) + 5;
      });
    }, 200);

    return () => clearInterval(timer);
  }, [onLoaded]);

  return (
    <motion.div
      initial={{ opacity: 1 }}
      exit={{ opacity: 0, y: -50 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-cream overflow-hidden"
    >
      {/* Background Decor */}
      <div className="absolute inset-0 flex items-center justify-center opacity-30">
        <div className="w-[80vw] h-[80vw] max-w-[600px] max-h-[600px] bg-mango rounded-full blur-3xl" />
      </div>

      <div className="relative z-10 flex flex-col items-center">
        {/* Simple Bottle / Mango Animation */}
        <div className="relative w-32 h-48 rounded-[2rem] border-4 border-mango/30 overflow-hidden mb-8 bg-white/50 backdrop-blur-sm shadow-xl p-1">
          <div className="absolute top-[-10px] left-1/2 -translate-x-1/2 w-8 h-4 bg-mango rounded-t-xl" />
          
          <motion.div 
            className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-deep to-mango rounded-[1.8rem]"
            initial={{ height: "0%" }}
            animate={{ height: `${progress}%` }}
            transition={{ ease: "linear" }}
          >
            {/* Bubbles could go here */}
          </motion.div>
        </div>

        <motion.h2 
          className="text-dark-brown font-display font-bold text-3xl tracking-tight mb-4"
          animate={{ opacity: [0.5, 1, 0.5] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
        >
          Squeezing Mangoes...
        </motion.h2>
        
        <div className="w-64 h-2 bg-dark-brown/10 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-gradient-to-r from-mango to-fresh rounded-full"
            initial={{ width: "0%" }}
            animate={{ width: `${progress}%` }}
            transition={{ ease: "linear" }}
          />
        </div>
      </div>
    </motion.div>
  );
}
