import { useRef } from 'react';
import { ShoppingCart } from 'lucide-react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';

const products = [
  {
    name: "Classic Burst",
    price: "₹45",
    description: "The original summer classic packed with fresh juice.",
    image: "https://images.unsplash.com/photo-1550461716-2c6e61298cbe?auto=format&fit=crop&q=80&w=600&h=600",
  },
  {
    name: "Golden Fizz",
    price: "₹50",
    description: "Sparkling real mango delight with a citrus twist.",
    image: "https://images.unsplash.com/photo-1546173159-315724a31696?auto=format&fit=crop&q=80&w=600&h=600",
  },
  {
    name: "Tropical Blend",
    price: "₹65",
    description: "A thick, juicy blend of multiple exotic varieties.",
    image: "https://images.unsplash.com/photo-1621269359146-512c140cbb17?auto=format&fit=crop&q=80&w=600&h=600",
  },
  {
    name: "Sunrise Nectar",
    price: "₹80",
    description: "A smooth, velvet-like premium nectar for mornings.",
    image: "https://images.unsplash.com/photo-1601493700631-2b16ec4b4716?auto=format&fit=crop&q=80&w=600&h=600",
  }
];

export function Products() {
  const container = useRef<HTMLDivElement>(null);
  const scrollWrapper = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    // Reveal animation
    gsap.from('.product-title', {
      opacity: 0,
      y: 50,
      scrollTrigger: {
        trigger: container.current,
        start: 'top 80%',
      }
    });

    // Horizontal Scrolling section
    const sections = gsap.utils.toArray('.product-card');
    gsap.to(sections, {
      xPercent: -100 * (sections.length - 1),
      ease: "none",
      scrollTrigger: {
        trigger: container.current,
        pin: true,
        scrub: 1,
        snap: 1 / (sections.length - 1),
        start: "top top",
        end: () => "+=" + scrollWrapper.current?.offsetWidth
      }
    });

    // Hover mouse follow effect for cards setup manually
    const cards = document.querySelectorAll('.product-card-inner');
    cards.forEach(card => {
      card.addEventListener('mousemove', (e: any) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left - rect.width / 2;
        const y = e.clientY - rect.top - rect.height / 2;
        
        gsap.to(card, {
          rotationY: x * 0.05,
          rotationX: -y * 0.05,
          ease: "power2.out",
          duration: 0.5
        });
      });

      card.addEventListener('mouseleave', () => {
        gsap.to(card, {
          rotationY: 0,
          rotationX: 0,
          ease: "elastic.out(1, 0.3)",
          duration: 1
        });
      });
    });

  }, { scope: container });

  return (
    <section id="products" ref={container} className="h-[100svh] w-full relative overflow-hidden flex items-center bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-cream via-cream to-mango/10">
      {/* Decorative Background Rays */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-[1000px] h-full pointer-events-none opacity-20 z-0">
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-mango via-transparent to-transparent opacity-50 blur-3xl"></div>
      </div>

      <div className="absolute top-[10svh] left-0 right-0 z-10 pointer-events-none">
        <div className="max-w-7xl mx-auto px-6 product-title text-center">
          <h2 className="text-4xl md:text-6xl font-display font-bold text-dark-brown mb-2 md:mb-4">
            Our <span className="text-mango drop-shadow-md">Juicy Selection</span>
          </h2>
          <p className="text-sm md:text-xl text-body max-w-2xl mx-auto">
            Scroll to explore the exotic rush of the tropics.
          </p>
        </div>
      </div>

      <div ref={scrollWrapper} className="flex h-full items-center pt-[15svh] md:pt-[20svh] w-max px-[10vw] md:px-[20vw] z-10 relative">
        {products.map((product, idx) => (
          <div
            key={product.name}
            className="product-card w-[85vw] md:w-[35vw] max-w-[340px] md:max-w-[380px] flex-shrink-0 px-2 md:px-6 perspective-[1000px]"
          >
            <div className="product-card-inner flex flex-col relative rounded-[2rem] p-5 md:p-8 custom-glassmorphism overflow-hidden bg-white/40 hover:bg-white/60 transition-colors transform-style-3d shadow-[0_20px_40px_rgba(0,0,0,0.1)]">
              {/* Shine Sweep Animation Setup */}
              <div className="absolute inset-0 -translate-x-full bg-gradient-to-r from-transparent via-white/50 to-transparent hover:animate-[shimmer_1.5s_infinite] transition-all z-20 pointer-events-none"></div>

              <div className="relative z-10 flex flex-col items-center text-center transform-translate-z-50 h-full">
                <div className="w-full h-40 md:h-56 rounded-[1.5rem] overflow-hidden mb-4 relative shadow-md">
                  <img 
                    src={product.image} 
                    alt={product.name} 
                    className="w-full h-full object-cover"
                  />
                  {/* Price Badge */}
                  <div className="absolute top-3 right-3 bg-golden px-4 py-1.5 rounded-full font-bold text-dark-brown shadow-lg backdrop-blur-md text-sm md:text-base border border-white/40">
                    {product.price}
                  </div>
                </div>

                <div className="flex-grow flex flex-col justify-center">
                  <h3 className="text-2xl md:text-3xl font-display font-bold text-dark-brown mb-2 leading-tight">
                    {product.name}
                  </h3>
                  <p className="text-body text-xs md:text-sm mb-4 leading-relaxed">
                    {product.description}
                  </p>
                </div>

                <a 
                  href={`https://wa.me/919876543210?text=I'm%20interested%20in%20${encodeURIComponent(product.name)}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-full py-3.5 md:py-4 bg-gradient-to-r from-mango to-fresh text-white rounded-full font-bold text-sm md:text-base shadow-[0_4px_15px_rgba(255,193,7,0.4)] hover:shadow-[0_0_30px_rgba(255,193,7,0.6)] transition-all duration-300 flex items-center justify-center gap-2 group hover:scale-[1.02] transform-translate-z-20 mt-auto"
                >
                  <ShoppingCart className="w-4 h-4 md:w-5 md:h-5 group-hover:scale-110 transition-transform" />
                  Order on WhatsApp
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
