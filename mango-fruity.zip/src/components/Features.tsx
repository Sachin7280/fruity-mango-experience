import { useRef } from 'react';
import { Leaf, Sun, Droplets } from 'lucide-react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';

const features = [
  {
    icon: <Sun className="w-8 h-8 text-mango" />,
    title: "Sun-Ripened Magic",
    description: "Every mango is kissed by the tropical sun, ensuring peak sweetness."
  },
  {
    icon: <Droplets className="w-8 h-8 text-mango" />,
    title: "Freshly Squeezed",
    description: "Cold-pressed to lock in the vibrant, natural taste and golden color."
  },
  {
    icon: <Leaf className="w-8 h-8 text-leaf" />,
    title: "100% Organic",
    description: "No artificial flavors. Just pure, unadulterated mango goodness."
  }
];

export function Features() {
  const container = useRef<HTMLElement>(null);

  useGSAP(() => {
    gsap.from('.feature-card', {
      opacity: 0,
      y: 60,
      stagger: 0.2,
      duration: 1,
      ease: 'back.out(1.4)',
      scrollTrigger: {
        trigger: container.current,
        start: 'top 75%',
      }
    });
  }, { scope: container });

  return (
    <section id="features" ref={container} className="py-32 relative overflow-hidden z-20">
      <div className="absolute left-0 top-0 w-64 h-64 bg-mango rounded-full blur-[100px] opacity-20 -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute right-0 bottom-0 w-64 h-64 bg-deep rounded-full blur-[100px] opacity-10 translate-x-1/2 translate-y-1/2" />
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="feature-card flex flex-col items-center text-center group"
            >
              <div className="w-24 h-24 rounded-[2rem] bg-white shadow-xl flex items-center justify-center mb-8 group-hover:-translate-y-3 transition-transform duration-500 relative">
                <div className="absolute inset-0 bg-mango/10 rounded-[2rem] scale-0 group-hover:scale-100 transition-transform duration-500"></div>
                <div className="relative z-10 drop-shadow-sm">
                  {feature.icon}
                </div>
              </div>
              <h3 className="text-3xl font-display font-bold text-dark-brown mb-4">{feature.title}</h3>
              <p className="text-body text-lg max-w-xs">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
