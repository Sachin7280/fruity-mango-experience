import { useRef } from 'react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';

export function Visuals() {
  const containerRef = useRef<HTMLDivElement>(null);

  useGSAP(() => {
    // Title reveal
    gsap.from('.visuals-title', {
      opacity: 0,
      y: 50,
      duration: 1,
      scrollTrigger: {
        trigger: containerRef.current,
        start: 'top 80%',
      }
    });

    // Parallax Videos
    gsap.fromTo('.visual-video-1', 
      { y: 100 },
      {
        y: -100,
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true,
        }
      }
    );

    gsap.fromTo('.visual-video-2', 
      { y: -100 },
      {
        y: 100,
        ease: 'none',
        scrollTrigger: {
          trigger: containerRef.current,
          start: 'top bottom',
          end: 'bottom top',
          scrub: true,
        }
      }
    );

    // Large central video scale up
    gsap.fromTo('.visual-video-large', 
      { scale: 0.8 },
      {
        scale: 1,
        ease: 'none',
        scrollTrigger: {
          trigger: '.visual-video-large',
          start: 'top bottom',
          end: 'center center',
          scrub: true,
        }
      }
    );

  }, { scope: containerRef });

  return (
    <section id="visuals" ref={containerRef} className="py-32 overflow-hidden relative z-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="visuals-title text-center mb-24">
          <h2 className="text-5xl md:text-7xl font-display font-bold text-dark-brown mb-6">
            Pure <span className="text-mango">Sunshine</span><br/> in a Bottle
          </h2>
          <p className="text-xl text-body max-w-2xl mx-auto">
            Experience the vibrant, refreshing rush of real mango goodness. Crafted for those who crave the extraordinary.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-center">
          <div className="visual-video-1 rounded-[2.5rem] overflow-hidden shadow-2xl relative aspect-[4/5] group">
            <video 
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
              autoPlay loop muted playsInline
              src="https://res.cloudinary.com/dmd5z0hzi/video/upload/q_auto/f_auto/v1780310784/5c7f56563a15f1259c6ebb76c4d6d321_540w_bg36x3.mp4"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark-brown/60 to-transparent"></div>
            <div className="absolute bottom-10 left-10 right-10">
              <h3 className="text-3xl font-display font-bold text-white mb-2">Tropical Rush</h3>
              <p className="text-white/80">Feel the breeze with every sip.</p>
            </div>
          </div>

          <div className="visual-video-2 rounded-[2.5rem] overflow-hidden shadow-2xl relative aspect-[4/5] group mt-10 md:mt-32">
            <video 
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110"
              autoPlay loop muted playsInline
              src="https://res.cloudinary.com/dmd5z0hzi/video/upload/q_auto/f_auto/v1780310784/cc24e531bff9c365dce63b931dc2f532_540w_os3zaf.mp4"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-dark-brown/60 to-transparent"></div>
            <div className="absolute bottom-10 left-10 right-10">
              <h3 className="text-3xl font-display font-bold text-white mb-2">Mango Glow</h3>
              <p className="text-white/80">Radiate energy, stay refreshed.</p>
            </div>
          </div>
        </div>

        {/* Large Central Video Showcase */}
        <div className="visual-video-large mt-32 rounded-[3rem] overflow-hidden shadow-2xl relative aspect-video group">
           <video 
              className="absolute inset-0 w-full h-full object-cover"
              autoPlay loop muted playsInline
              src="https://res.cloudinary.com/dmd5z0hzi/video/upload/q_auto/f_auto/v1780310786/3ed5e34e0f9ae7d1efafdaad0d760a10_720w_wmqeqi.mp4"
            />
            {/* Dark overlay for text readability */}
            <div className="absolute inset-0 bg-black/30 group-hover:bg-black/10 transition-colors duration-500"></div>
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                <h2 className="text-5xl md:text-8xl font-display font-bold text-white drop-shadow-xl text-center px-4">
                  Taste The <br className="md:hidden" />
                  <span className="text-mango">Summer</span>
                </h2>
            </div>
        </div>
      </div>
    </section>
  );
}
