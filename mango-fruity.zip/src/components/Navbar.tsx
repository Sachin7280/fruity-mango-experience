import { useRef, useState } from 'react';
import { Leaf, Menu, X } from 'lucide-react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';

export function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  useGSAP(() => {
    const onScroll = () => {
      if (window.scrollY > 50 && !isScrolled) {
        setIsScrolled(true);
        gsap.to(navRef.current, {
          backgroundColor: 'rgba(255, 255, 255, 0.75)',
          backdropFilter: 'blur(20px)',
          borderColor: 'rgba(255, 255, 255, 0.4)',
          boxShadow: '0 4px 30px rgba(0, 0, 0, 0.05)',
          duration: 0.3
        });
      } else if (window.scrollY <= 50 && isScrolled) {
        setIsScrolled(false);
        gsap.to(navRef.current, {
          backgroundColor: 'rgba(255, 255, 255, 0)',
          backdropFilter: 'blur(0px)',
          borderColor: 'rgba(255, 255, 255, 0.1)',
          boxShadow: 'none',
          duration: 0.3
        });
      }
    };

    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, [isScrolled]);

  return (
    <nav
      ref={navRef}
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300 border-b border-white/10"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 h-16 md:h-20 flex items-center justify-between">
        <a href="#" className="flex items-center gap-2 group z-50">
          <div className="w-8 h-8 md:w-10 md:h-10 bg-gradient-to-br from-mango to-fresh rounded-xl flex items-center justify-center shadow-lg group-hover:scale-105 transition-transform duration-300 relative overflow-hidden flex-shrink-0">
            <div className="absolute inset-0 bg-white/30 skew-x-12 -translate-x-full group-hover:animate-[shimmer_1s_forwards]"></div>
            <Leaf className="text-white w-4 h-4 md:w-5 md:h-5 drop-shadow-md relative z-10" />
          </div>
          <span className="font-display font-bold text-xl md:text-2xl text-dark-brown tracking-tight flex items-center bg-white/40 backdrop-blur-md px-3 py-1 rounded-full border border-white/50 shadow-sm">
            Mango<span className="text-fresh drop-shadow-sm">Magic</span>
          </span>
        </a>

        {/* Desktop Menu */}
        <div className="hidden md:flex items-center gap-10 bg-white/50 backdrop-blur-xl px-8 py-2.5 rounded-full border border-white/60 shadow-sm font-sans font-semibold text-dark-brown/90 text-sm tracking-wide">
          <a href="#features" className="hover:text-fresh transition-colors relative after:absolute after:-bottom-1 after:left-0 after:w-0 after:h-0.5 after:bg-fresh hover:after:w-full after:transition-all after:duration-300">Features</a>
          <a href="#products" className="hover:text-fresh transition-colors relative after:absolute after:-bottom-1 after:left-0 after:w-0 after:h-0.5 after:bg-fresh hover:after:w-full after:transition-all after:duration-300">Products</a>
          <a href="#visuals" className="hover:text-fresh transition-colors relative after:absolute after:-bottom-1 after:left-0 after:w-0 after:h-0.5 after:bg-fresh hover:after:w-full after:transition-all after:duration-300">Experience</a>
        </div>

        {/* Action Button & Mobile Toggle */}
        <div className="flex items-center gap-2 z-50">
          <a 
            href="https://wa.me/919876543210?text=I'd%20like%20to%20order%20Mango%20Magic!"
            target="_blank"
            rel="noopener noreferrer"
            className="hidden md:flex px-6 py-2.5 bg-gradient-to-r from-mango to-fresh text-white rounded-full font-bold shadow-[0_4px_15px_rgba(255,193,7,0.4)] hover:shadow-[0_6px_25px_rgba(255,193,7,0.6)] hover:-translate-y-0.5 transition-all duration-300 active:scale-95 items-center gap-2"
          >
            Order Now
          </a>
          <button 
            className="md:hidden w-10 h-10 flex items-center justify-center bg-white/40 backdrop-blur-md rounded-full border border-white/50 text-dark-brown"
            onClick={() => setMenuOpen(!menuOpen)}
          >
            {menuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Overlay */}
      {menuOpen && (
        <div className="absolute top-full left-0 right-0 bg-white/95 backdrop-blur-xl border-b border-white/20 shadow-xl flex flex-col p-4 gap-4 md:hidden z-40">
          <a href="#features" onClick={() => setMenuOpen(false)} className="px-4 py-3 font-semibold text-dark-brown bg-cream/50 rounded-xl">Features</a>
          <a href="#products" onClick={() => setMenuOpen(false)} className="px-4 py-3 font-semibold text-dark-brown bg-cream/50 rounded-xl">Products</a>
          <a href="#visuals" onClick={() => setMenuOpen(false)} className="px-4 py-3 font-semibold text-dark-brown bg-cream/50 rounded-xl">Experience</a>
          <a 
            href="https://wa.me/919876543210?text=I'd%20like%20to%20order%20Mango%20Magic!"
            className="mt-2 w-full py-4 text-center bg-gradient-to-r from-mango to-fresh text-white font-bold rounded-xl shadow-lg"
          >
            Order on WhatsApp
          </a>
        </div>
      )}
    </nav>
  );
}
