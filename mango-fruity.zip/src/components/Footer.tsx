import { Leaf, Instagram, Twitter, Facebook } from 'lucide-react';

export function Footer() {
  return (
    <footer className="bg-dark-brown text-cream pt-20 pb-10 relative overflow-hidden">
      {/* Decorative top wave/glow */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-mango via-golden to-fresh"></div>
      
      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 md:col-span-2">
            <a href="#" className="flex items-center gap-2 mb-6">
              <div className="w-10 h-10 bg-gradient-to-br from-mango to-fresh rounded-xl flex items-center justify-center">
                <Leaf className="text-white w-5 h-5 drop-shadow-md" />
              </div>
              <span className="font-display font-bold text-3xl text-white tracking-tight">
                Mango<span className="text-mango">Magic</span>
              </span>
            </a>
            <p className="text-cream/70 max-w-sm">
              Bringing the freshest, most vibrant tropical energy straight to your tastebuds. Sip the sunshine, taste the magic.
            </p>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-6 text-mango">Quick Links</h4>
            <ul className="space-y-4 text-cream/70">
              <li><a href="#features" className="hover:text-mango transition-colors">Our Story</a></li>
              <li><a href="#products" className="hover:text-mango transition-colors">Shop Products</a></li>
              <li><a href="#" className="hover:text-mango transition-colors">Find a Store</a></li>
              <li><a href="#" className="hover:text-mango transition-colors">Contact Us</a></li>
            </ul>
          </div>

          <div>
            <h4 className="font-display font-bold text-lg mb-6 text-mango">Follow the Sun</h4>
            <div className="flex gap-4">
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-mango hover:text-dark-brown transition-all duration-300">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-mango hover:text-dark-brown transition-all duration-300">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-mango hover:text-dark-brown transition-all duration-300">
                <Facebook className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row items-center justify-between gap-4 text-sm text-cream/60">
          <p>&copy; {new Date().getFullYear()} Mango Magic Inc. All rights reserved.</p>
          <div className="flex gap-6">
            <a href="#" className="hover:text-cream transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-cream transition-colors">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
