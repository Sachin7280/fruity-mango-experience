import { useRef } from 'react';
import { ArrowRight } from 'lucide-react';
import gsap from 'gsap';
import { useGSAP } from '@gsap/react';
import SplitType from 'split-type';

export function Hero() {
  const container = useRef<HTMLElement>(null);
  const textRef = useRef<HTMLHeadingElement>(null);

  useGSAP(() => {
    // 1. Text Reveal Character by Character
    if (textRef.current) {
      const text = new SplitType(textRef.current, { types: 'chars,words' });
      gsap.from(text.chars, {
        opacity: 0,
        y: 50,
        rotateX: -90,
        stagger: 0.02,
        duration: 1,
        ease: 'back.out(1.7)',
        delay: 0.5,
      });
    }

    // 2. Parallax background video scaling
    gsap.to('.hero-video', {
      scale: 1.15,
      scrollTrigger: {
        trigger: container.current,
        start: 'top top',
        end: 'bottom top',
        scrub: true,
      }
    });

    // 3. Floating Mango Parallax (tied to scroll)
    gsap.utils.toArray('.mango-particle').forEach((particle: any, i) => {
      // Continuous float
      gsap.to(particle, {
        y: '+=30',
        x: '+=20',
        rotation: '+=15',
        yoyo: true,
        repeat: -1,
        duration: 3 + i,
        ease: 'sine.inOut'
      });
      // Scroll parallax
      gsap.to(particle, {
        y: -200 * (i % 3 + 1),
        scrollTrigger: {
          trigger: container.current,
          start: 'top top',
          end: 'bottom top',
          scrub: true,
        }
      });
    });

    // Subtext and buttons fade in
    gsap.from('.hero-subcontent', {
      opacity: 0,
      y: 30,
      stagger: 0.2,
      duration: 1,
      delay: 1.5,
      ease: 'power3.out'
    });

  }, { scope: container });

  return (
    <section ref={container} className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Video */}
      <div className="absolute inset-0 w-full h-full overflow-hidden">
        <video 
          className="hero-video w-full h-full object-cover origin-center"
          autoPlay 
          loop 
          muted 
          playsInline
          src="https://res.cloudinary.com/dmd5z0hzi/video/upload/q_auto/f_auto/v1780311891/Generate_high_quality_video_anim__202606011634_ujuxdc.mp4"
        />
        {/* Soft yellow gradient, Golden sunlight effect, Mango glow effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-black/60 via-black/40 to-black/80 mix-blend-overlay z-0"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-dark-brown/80 via-dark-brown/40 to-dark-brown z-0"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-6 w-full pt-20 flex flex-col items-center text-center">
        <div className="max-w-4xl perspective-[1000px]">
          <h1 
            ref={textRef}
            className="font-display font-bold text-6xl md:text-8xl text-soft drop-shadow-2xl leading-tight mb-6"
            style={{ clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0% 100%)' }} // helps with split text rendering
          >
            Taste the Real <br/>
            <span className="text-mango drop-shadow-[0_0_30px_rgba(255,193,7,0.8)]">Mango Magic</span>
          </h1>
          
          <p className="hero-subcontent text-lg md:text-2xl text-cream font-medium mb-10 drop-shadow-md max-w-2xl mx-auto">
            A tropical escape in every sip. Refreshing, vibrant, and bursting with the golden sunshine of summer.
          </p>
          
          <div className="hero-subcontent flex flex-col sm:flex-row items-center justify-center gap-4">
            <a 
              href="https://wa.me/919876543210?text=I'd%20like%20to%20order%20Mango%20Magic!"
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center gap-2 px-8 py-4 bg-gradient-to-r from-mango to-fresh text-white rounded-full font-bold text-lg shadow-[0_0_20px_rgba(255,193,7,0.5)] hover:shadow-[0_0_40px_rgba(255,193,7,0.8)] hover:scale-105 transition-all duration-300 relative z-40"
            >
              Order on WhatsApp
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>
            <button 
              onClick={() => document.getElementById('visuals')?.scrollIntoView({ behavior: 'smooth' })}
              className="px-8 py-4 bg-white/20 backdrop-blur-md border border-white/30 text-white rounded-full font-bold text-lg hover:bg-white/30 transition-all duration-300 relative z-40"
            >
              Watch Video
            </button>
          </div>
        </div>
      </div>

      {/* Floating particles effect */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden z-0">
        {[...Array(10)].map((_, i) => (
          <div
            key={i}
            className="mango-particle absolute rounded-full bg-mango/40 blur-md"
            style={{
              width: Math.random() * 20 + 20,
              height: Math.random() * 20 + 20,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              opacity: 0.6,
            }}
          />
        ))}
      </div>
    </section>
  );
}
